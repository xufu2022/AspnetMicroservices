﻿if (!$hostApi) { $hostApi= 'https://api.stackify.net' }

$post = 'https://api.stackify.net/api/v1/deployments/complete'

$headers = @{'authorization'='ApiKey ' + '$(Stackify.ApiKey)'}

$bodyObj = @{ 
Name = '$(Release.ReleaseName)';
Version='$(Release.ReleaseId)';
AppName='Your_AppName';
EnvironmentName='$(Release.EnvironmentName)';
Uri = '$(Release.EnvironmentUri)';
Branch = '$(Build.SourceBranchName)';
Commit = '$(Build.SourceVersion)';
}

$body = ConvertTo-Json $bodyObj

# send the request
Invoke-WebRequest -Proxy "http://tq-proxy:8080" -Uri $post -Method POST -ContentType "application/json" -Headers $headers -Body $body -UseBasicParsing