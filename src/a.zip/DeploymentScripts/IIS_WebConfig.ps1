﻿
Param(
    [Parameter(Mandatory = $true)][string]$DeploymentPath,
    [Parameter(Mandatory = $true)][string]$AspNetCoreEnvironment,
    [Parameter(Mandatory = $true)][string]$LogEnabled,
    [Parameter(Mandatory = $true)][string]$LogPath
)

Function setEnvironment {

    param([string]$aspEnvironment )

    Write-Host -ForegroundColor Yellow "Setting ASP.Net Core web.config variables"

    try {
        Write-Host "Searching for ASPNETCORE_ENVIRONMENT node"
       
        $nodes = $doc.SelectNodes("/configuration/system.webServer/aspNetCore/environmentVariables/environmentVariable")            
        $envrionmentNodeExists = $false
        foreach ($node in $nodes) {
            if ($node.name -ceq 'ASPNETCORE_ENVIRONMENT') {                    
                $node.SetAttribute("value", $aspEnvironment);
                Write-Host "ASPNETCORE_ENVIRONMENT node set to: "$aspEnvironment
                $envrionmentNodeExists = $true
            } 
        }           
        if(-not $envrionmentNodeExists){
            throw "ASPNETCORE_ENVIRONMENT node doesnt exist! WTF DO WE DO NOW!?  "
        }

        Write-Host "Searching for optional ASPNETCORE_HTTPS_PORT node"
        $httpNode = $nodes.ASPNETCORE_HTTPS_PORT 
        if ($httpNode) {
            foreach ($node in $nodes) {                
                if ($node.name -ceq 'ASPNETCORE_HTTPS_PORT') {                   
                    $node.SetAttribute("value", '443');
                    Write-Host "ASPNETCORE_HTTPS_PORT node set to: 443 cause thats secure init."
                }
            }         
        } 
    }
    catch {
        Write-Host -ForegroundColor Red $_.Exception.Message;
        throw "Something bad happned further up.. Im outta here!!" 
    } 
}    

Function setLogging {
    param([string]$logEnabled, [string]$logPath )
  
    Write-Host -ForegroundColor Yellow "Logs enabled is set to $logEnabled and log path set to $logPath"
    try {

        $nodes = $doc.SelectNodes("/configuration/system.webServer/aspNetCore")
  
        foreach ($node in $nodes) {
            $node.SetAttribute("stdoutLogEnabled", $logEnabled)
            $node.SetAttribute("stdoutLogFile", $logPath)
        }
        Write-Host -ForegroundColor Green "Set!"  
    }
    catch {
        Write-Host -ForegroundColor Red $_.Exception.Message   
    }
}

$webConfig = "$DeploymentPath\web.config"
$doc = [Xml](Get-Content $webConfig)

setEnvironment -aspEnvironment $AspNetCoreEnvironment 
setLogging -logEnabled $LogEnabled -logPath $LogPath

try {
    $doc.Save($webConfig)
}
catch {
    Write-Host -ForegroundColor Red $_.Exception.Message   
}