$Servers = "SVR-POCWEBARR","SVR-POCWEBARR2","SVR-POCWEB01","SVR-POCWEB02","SVR-POCAPI01","SVR-POCAPI02","SVR-POCLBAPI01","SVR-POCLBAPI02"


foreach ($computer in $Servers) {
    Write-Host "Details from server $computer..."

    Invoke-command  -ComputerName $computer  -ScriptBlock {

        # Ensure to import the WebAdministration module

        Import-Module WebAdministration
        set-Location IIS:\AppPools
                
        #Get the Application Pools of the server

        $appPoolCollections = dir
        foreach ($pool in $appPoolCollections) {
            # Loop through the collection and find the status of the appPool 
            $appPoolName = $pool.Name
            $appPoolState = $pool.state
            $appPoolVersion = $pool.managedRuntimeVersion
            Write-Host "$appPoolName with version $appPoolVersion is $appPoolState"

        }
    }
    Write-Host "++++++++++++++++++++++++++++++++++++++++++++++++++++++"
}