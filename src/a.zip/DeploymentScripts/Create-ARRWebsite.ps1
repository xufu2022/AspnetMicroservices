
Param(
    [Parameter(Mandatory = $true)][string]$SiteFolderPath,
    [Parameter(Mandatory = $true)][string]$SiteAppPool,
    [Parameter(Mandatory = $true)][string]$SiteName,
    [Parameter(Mandatory = $true)][string]$SiteHostName,
    [Parameter(Mandatory = $true)][string]$Environment,
    [Parameter(Mandatory = $true)][string]$IPAddress    
)


$indexFile = @"
<!DOCTYPE html>
<html>
    <head>
        <title>Error!</title>
    </head>
    <body>
        <h3>Welcome The Incommunities <strong>$SiteHostName $Environment</strong> Page!&nbsp;</h3>
        <h2>$env:COMPUTERNAME</h2>
        <div>If you are reading this, then something went wrong with our web servers&nbsp;<img src="https://html5-editor.net/tinymce/plugins/emoticons/img/smiley-cry.gif" alt="cry" /></div>
        <div>&nbsp;</div>
        <div>Please contact <strong>ICT 01274 251111</strong></div>
    </body>
</html> 
"@

#check Binding ip address exists on machine
$ips = Get-NetIPAddress -AddressFamily IPv4 | select IPAddress | Where-Object {$_.IPAddress -eq $IPAddress}

if ($ips) {
    Write-Host -ForegroundColor Green "IP Address OK!"    

    try {

        # Check site exisitence
        if (-not (get-website | where-object { $_.name -eq $SiteName })) {
             
            Write-Host "Creating Website:" $SiteName `n

            # Check directory
            if (-not(Test-Path $SiteFolderPath)) {
            
                Write-Host "Creating directory:" $SiteFolderPath `n
            
                New-Item $SiteFolderPath -type Directory
            }

            # Check index page        
            if (-not(Test-Path "$SiteFolderPath\index.html")) {
            
                Write-Host "Creating Index page `n"
                Out-File -FilePath $SiteFolderPath\index.html -InputObject $indexFile           
            }

            # Check AppPool
            if (-not (Get-ChildItem IIS:\AppPools\ | Where-Object { $_.Name -eq $SiteAppPool})) {
                Write-Host "Creating App Pool `n"

                New-Item -Path IIS:\AppPools\$SiteAppPool 
                Set-ItemProperty -Path IIS:\AppPools\$SiteAppPool -Name managedRuntimeVersion -Value 'v4.0'
            }

            # Create new site
            try {
                New-Website -Name $SiteName -Port 443 -HostHeader $SiteHostName -PhysicalPath $SiteFolderPath -IPAddress $IPAddress -SslFlags '3' -ssl -ApplicationPool $SiteAppPool
            
                Write-Host -ForegroundColor Green "Binding added!"    

            }
            catch {
                Write-Host -ForegroundColor Red $_.Exception.Message
            }      

 
        }
        else {
        
            Write-Host -ForegroundColor Red "Website: $SiteName already exisits!"
        }


    }
    catch {
        Write-Host -ForegroundColor Red $_.Exception.Message
    }
}
else {
    Write-Host -ForegroundColor red "IPAddress does not exist on this machine!"
}
