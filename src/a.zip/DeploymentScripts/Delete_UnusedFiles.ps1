Param(
    [Parameter(Mandatory = $true)][string]$TargetPath  
)

Write-Host 'Preparing to delete config transformation files in $TargetPath:' $TargetPath

function DeleteIfConfigTransformFile($file)
{
    try
    {
        $xdoc = New-Object System.Xml.XmlDocument
        $xdoc.Load($file)

        if($xdoc.DocumentElement.xdt -eq "http://schemas.microsoft.com/XML-Document-Transform")
        {
            Write-Host "Deleting file:" $file
            Remove-Item $file
        }
        else
        {
            Write-Host "Not deleting config file as it may not be a web.config file" $file
        }
    }
    catch
    {
        Write-Host "Could not xml parse file:" $file
    }

}

Get-ChildItem $TargetPath -Recurse | Where-Object { $_.Name -like "*.config" } | ForEach-Object { DeleteIfConfigTransformFile ($_.FullName) }