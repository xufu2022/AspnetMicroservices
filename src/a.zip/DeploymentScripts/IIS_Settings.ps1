﻿Param(
    [Parameter(Mandatory = $true)][string]$Hostname,
    [Parameter(Mandatory = $true)][string]$BindingIpAddress
)

# Get the site detals
$site = Get-Website -Name $hostname

# Get the application pool reference
$appPool = Get-ChildItem IIS:\AppPools\ | Where-Object { $_.Name -eq $site.applicationPool }

function checkBinding {
    param (
        [Parameter(Mandatory = $true)][string]$hostname,
        [Parameter(Mandatory = $true)][string]$bindingIpAddress
    )
    
    Write-Host "Checking for website binding..."

    try {    
        $iisBinding = $("$bindingIpAddress :443: $hostname").Replace(' ', '')

        # Check if binding exists for site
        if (Get-WebBinding -Name $hostname) {
            Write-Host -ForegroundColor Green "Binding found! Checking binding config..."         
        

            # Check if binding settings are correct
            # If not correct remove and add correct binding
            if (!(Get-WebBinding -Name $hostname | Where-Object {($_.sslFlags -eq 2) -and ($_.protocol -eq "https") -and ($_.bindingInformation -eq $iisBinding)})) {
    
                Write-Host -ForegroundColor Yellow "Bad news the existing binding config is incorrect!... this will be removed!"

                # Remove incorrect web binding
                Get-WebBinding -Name $hostname|  Remove-WebBinding             
            
                Write-Host "Adding new binding..."
                addBinding -hostname $hostname -bindingIpAddress $bindingIpAddress
            }
    
            else {        
                Write-Host -ForegroundColor Green "Good news everyone! The exisiting binding config is correct!"
            } 
        }
        else {
            
            Write-Host -ForegroundColor Yellow "No binding found for $iisBinding! a new one will be added"
            addBinding -hostname $hostname -bindingIpAddress $bindingIpAddress
        }    
    }
    catch {
        # Opps
        Write-Host -ForegroundColor Red $_.Exception.Message
    }
}

function addBinding {
    
    param (
        [Parameter(Mandatory = $true)][string]$hostname,
        [Parameter(Mandatory = $true)][string]$bindingIpAddress
    )

    try {     
        New-WebBinding -Name $hostname -IPAddress $bindingIpAddress -Port 443 -Protocol https -HostHeader $hostname -SslFlag "2"
        Write-Host -ForegroundColor Green "Binding added!"
    }

    catch {
        # Opps
        Write-Host -ForegroundColor Red $_.Exception.Message
    }
}

# Set User Profile
function setUserProfile {
    param (
        [Parameter(Mandatory = $true)][string]$hostname
    )

    try {
    
        $site = Get-Website -Name $hostname
        $appPool = Get-ChildItem IIS:\AppPools\ | Where-Object { $_.Name -eq $site.applicationPool }

        write-host "Checking if load user profile is enabled.."       
     

        if ($appPool.processModel.loadUserProfile -eq $false) {        
            Write-Host -ForegroundColor Yellow "User profile is set to false! Changing to True!"
            
            
            $appPool.processModel.loadUserProfile = $true 
            $appPool | Set-Item            
            
            Write-Host -ForegroundColor Green "User profile is set!"

        }
        else {
            Write-Host -ForegroundColor Green "User profile is already set to true!"
        }		
    }
    catch {
        # Opps
        Write-Host -ForegroundColor Red $_.Exception.Message   
    }  
}

# Set AppPool Start Mode
function setAppPoolStartMode {
    param (
        [Parameter(Mandatory = $true)][string]$hostname
    )
    Try {
            
        $site = Get-Website -Name $hostname
        $appPool = Get-ChildItem IIS:\AppPools\ | Where-Object { $_.Name -eq $site.applicationPool }
    
        write-host "Checking apppool startmode..."             
    
        #Set up AlwaysRunning
        if ($appPool.startMode -ne "AlwaysRunning") {
            Write-Host "startMode is set to $($appPool.startMode ), activating AlwaysRunning" -ForegroundColor Yellow
        
            $appPool | Set-ItemProperty -name "startMode" -Value "AlwaysRunning"
            $appPool = Get-ChildItem IIS:\AppPools\ | Where-Object { $_.Name -eq $site.applicationPool }
    
            Write-Host "startMode is now set to $($appPool.startMode)`n" -ForegroundColor Green
        } 
        else {
            Write-Host "startMode was already set to $($appPool.startMode) for the application pool $($site.applicationPool)" -ForegroundColor Yellow
        }
    }
    catch {
        Write-Host -ForegroundColor Red $_.Exception.Message   
    }
}

# Warning - There were issuses with the preload method. 
#           It only seemed to work once for each new site then
#           it would not work again!? - SM 
Function setWebSitePreload {
    param (
        [Parameter(Mandatory = $true)][string]$sitename
    )
      
    Write-Host "Checking preload config..."
      
    $site = Get-Website -name $sitename 
	  
    if ($site.applicationDefaults.preloadEnabled -eq $true) {
        Write-Host "preloadEnabled is active, deactivating"
      
        Set-ItemProperty "IIS:\Sites\$siteName" -Name applicationDefaults.preloadEnabled -Value False
      
        Write-Host "preloadEnabled is now set to $((Get-ItemProperty "IIS:\Sites\$siteName" -Name applicationDefaults.preloadEnabled).Value)" -ForegroundColor Green
    } 
     
    else {
        Write-Host "preloadEnabled already deactivated" -ForegroundColor Yellow
    }
  
}

# Test Site Exists
if (!$site) {
    Write-Host "Site $siteName could not be found, exiting!" -ForegroundColor Yellow
    Break
}
else {
	
    # Call
    checkBinding -hostname $Hostname -bindingIpAddress $BindingIpAddress
    setUserProfile -hostname $Hostname
    setAppPoolStartMode -hostname $Hostname
    setWebSitePreload -sitename $Hostname
}
exit