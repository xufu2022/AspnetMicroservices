﻿Param(
    [Parameter(Mandatory = $true)][string]$LogPath
)

function deleteLogs {    
    param (
        [Parameter(Mandatory = $true)][string]$logPath
    )

    try {     
        if (Test-Path $logPath) {
            $directoryInfo = Get-ChildItem $logPath | Measure-Object
            
            if ($directoryInfo.Count -gt 0) {
                Write-Host -ForegroundColor Green "Logs found, I will delete them!"
                Remove-Item -Path $logPath -Force -Recurse
            }
            else {
                Write-Host -ForegroundColor Red "Directory empty, nothing to delte"
            }            
        }
        else {
            Write-Host -ForegroundColor Red "Log path $logPath doesnt exist?"
        }        
    }
    catch {
        # Opps
        Write-Host -ForegroundColor Red "OH CRAP!! Check this out!"
        Write-Host -ForegroundColor Red $_.Exception.Message
    }
}

# Call
deleteLogs -logPath $LogPath

exit