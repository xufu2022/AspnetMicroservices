﻿param(
    [Parameter(Mandatory = $true)][string]$ExeFilePath,
    [Parameter(Mandatory = $true)][string]$ExeDirectory,
    [Parameter(Mandatory = $true)][string]$TaskName,
    [Parameter(Mandatory = $true)][string]$Username,
    [Parameter(Mandatory = $true)][string]$Password,
	[string]$Parameters,
    [string]$Time = "12am"
)


#If task already exists, unregister task.
if ($(Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue).TaskName -eq $TaskName) {
    Unregister-ScheduledTask -TaskName $TaskName -Confirm:$False
    Write-Host -ForegroundColor Green "A scheduled task with the name $TaskName was found. This task will now be removed and reconfigured."
} else {
    Write-Host -ForegroundColor Yellow "A scheduled task with the name $TaskName does not exist. This task will now be configured."
}

#Configure scheduled task object with passed settings.
if(!$Parameters) {
	Write-Host -ForegroundColor Green "Action is configured with no parameters."
	$Action = New-ScheduledTaskAction -Execute $ExeFilePath -WorkingDirectory $ExeDirectory
} else{
	Write-Host -ForegroundColor Green "Action is configured with parameters $Parameters."
	$Action = New-ScheduledTaskAction -Execute $ExeFilePath -Argument $Parameters -WorkingDirectory $ExeDirectory	
}
$Principal = New-ScheduledTaskPrincipal -UserId $Username -LogonType ServiceAccount -RunLevel Highest
$Trigger = New-ScheduledTaskTrigger -Daily -At $Time
$Settings = New-ScheduledTaskSettingsSet
$Task = New-ScheduledTask -Action $Action -Trigger $Trigger -Settings $Settings -Principal $Principal

Register-ScheduledTask -TaskName $TaskName -InputObject $Task -User $Username -Password $Password
Write-Host -ForegroundColor Green "Task $TaskName has now been configured to run at the time $Time daily."


