﻿
$Environment = "Test"

$csvPath = "\\SVR-PRDFS\DeploymentScript\Servers\WebsitesArrSettings.csv"

$importedSites = Import-Csv $csvPath | ? Environment -EQ $Environment 



foreach($website in $importedSites)
{
    
    $installPath = join-path $website.Install_Path $website.URL
   
   # Install site on ARR 1
   Write-Host -ForegroundColor Magenta "Installing:" $website.URL "on Server:" $website.Server1
   Invoke-command -ComputerName $website.Server1 -FilePath 'D:\Create-ARRWebsite.ps1' -ArgumentList $installPath,$website.URL,$website.URL,$website.URL,$Environment,$website.Server1_Binding 

   # Install site on ARR 2
   Write-Host -ForegroundColor Magenta "Installing:" $website.URL "on Server:" $website.Server2
   Invoke-command -ComputerName $website.Server2 -FilePath 'D:\Create-ARRWebsite.ps1' -ArgumentList $installPath,$website.URL,$website.URL,$website.URL,$Environment,$website.Server2_Binding 

}