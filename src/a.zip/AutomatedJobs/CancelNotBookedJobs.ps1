﻿# Variables
$ConnectionString = "Server=SVR-PRDSQL01;Database=RMS;Integrated Security=True"
$CrmApiUri = "https://crmapi.incommunities.co.uk/api/RMS/Repair/Cancel"
$SmtpServer = "172.16.16.61"
$EmailBody = [System.Text.StringBuilder]::new()


# C# Model definition for CancelRepairDto to pass in body of api call
$Dto = @"
using System;

namespace RMS.DTO.Repairs
{
    public class BaseDto
    {
        public long Id { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }
        public bool Active { get; set; }
        public byte[] RowVersion { get; set; }
        public string SuccessMessage { get; set; }
        public string ErrorMessage { get; set; }
    }

    public class CancelRepairDto : BaseDto
    {
    }
}
"@

$EmailBody.AppendLine("Cancellation status results:")
$EmailBody.AppendLine("")

# Register C# object as type
Add-Type -TypeDefinition $Dto


try{
    # Set up required sql settings and objects
    $SqlConnection = New-Object System.Data.SqlClient.SqlConnection -Property @{ConnectionString = $ConnectionString}
    $SqlCmd = New-Object System.Data.SqlClient.SqlCommand -Property @{CommandText = "p_GetNonBookedJobs"; Connection = $SqlConnection}
    $SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter -Property @{SelectCommand = $SqlCmd}
    $DataSet = New-Object System.Data.DataSet
    # Get list of repairs that have been created but not booked
    $SqlAdapter.Fill($DataSet)
}
catch {
    $Exception = "SQL Error occured when trying to get repairs to cancel: $($_.Exception.Message)"
    Send-MailMessage -From "automated-service@incommunities.co.uk" -To "ict-development@incommunities.co.uk" -Subject "Nightly Repairs Cancellation Results" -SmtpServer $SmtpServer -Body $Exception
}

# For each repair in repairs list 
foreach($Row in $DataSet.Tables[0].Rows)
{
    # Pass repair information to a new instance of the Dto
    $Dto = New-Object RMS.DTO.Repairs.CancelRepairDto
    $Dto.Id = $Row.Id
    $Dto.RowVersion = $Row.RowVersion

    # Call the crm api and capture the response
    try{
        $Response = Invoke-WebRequest -UseBasicParsing -Uri $CrmApiUri -Method PUT -ContentType "application/json" -Body ($Dto|ConvertTo-Json)
        $StatusCode = $Response.StatusCode
        $StatusDescription = $Response.StatusDescription

    }catch [System.Net.WebException] {
        Write-Verbose "An exception was caught: $($_.Exception.Message)"
        $StatusCode = $_.Exception.Response.StatusCode.value__ 
        $StatusDescription = $_.Exception.Response.StatusDescription
    }
    
    #Add results to email body string builder
    $Result = ("RepairID: {0} returned status {1} : {2}" -f $Dto.Id, $StatusCode, $StatusDescription)
    $EmailBody.AppendLine($Result)
}

$EmailBody.AppendLine("")
$EmailBody.AppendLine($ConnectionString)
$EmailBody.AppendLine($CrmApiUri)

Send-MailMessage -From "automated-service@incommunities.co.uk" -To "ict-development@incommunities.co.uk" -Subject "Nightly Repairs Cancellation Results" -SmtpServer $SmtpServer -Body $EmailBody
