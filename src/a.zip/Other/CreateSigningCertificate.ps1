﻿$cert = New-SelfsignedCertificate -KeyExportPolicy Exportable -Subject "ActiveIdentitySigningCertificate" -KeySpec Signature -KeyAlgorithm RSA -KeyLength 2048 -HashAlgorithm SHA256 -CertStoreLocation "cert:\localMachine\my\"

$pwd = ConvertTo-SecureString -String ‘vNya7mA9MguYQ4SKev8N’ -Force -AsPlainText

	
$path = 'cert:\localMachine\my\' + $cert.thumbprint 

Export-PfxCertificate -cert $path -FilePath c:\temp\ActiveIdentitySigningCertificate.pfx -Password $pwd