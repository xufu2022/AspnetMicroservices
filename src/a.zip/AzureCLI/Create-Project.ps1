﻿#Start logging
Start-Transcript -Path "$($PSScriptRoot)\create-project.log" -Append

#Imports
. "$($PSScriptRoot)\Helpers.ps1"

#Config
$ErrorActionPreference = "Stop"
$Pat = Get-Content "$($PSScriptRoot)\resources\pat.txt"
$Env:AZURE_DEVOPS_EXT_PAT = $Pat
$Env:AZURE_DEVOPS_EXT_GIT_SOURCE_PASSWORD_OR_PAT = $Pat

#Authenticate
Write-Host "Logging in using the local PAT token..."

$Pat | az devops login

try {
    az devops project list | out-null
    Write-Host 'Login is successful!' -BackgroundColor DarkGreen
}
catch {
    Write-Host 'Login unsuccessful, ensure the PAT token is present, valid and has not expired.' -BackgroundColor Red
    exit
}

#Obtain required information from user
Write-Host
$ProjectAlias = Read-Host "Please enter the name of the new project (e.g. CRMApi)"

Write-Host
$ProjectDescription = Read-Host "Please enter a description for the new project (e.g. A web application to view customer housing applications)"

Write-Host
$Framework = Read-Host "Please select the framework $($ProjectAlias) will use, type MVC / Vue / API"

while($Framework -ne "MVC" -And $Framework -ne "Vue" -And $Framework -ne "API") {
    Write-Host "$($Framework) does not match any of the given frameworks, please select either MVC / Vue / API" -BackgroundColor Red
    Write-Host
    $Framework = Read-Host "Please select the framework $($ProjectAlias) will use, type MVC / Vue / API"
}

Write-Host
$Hostname = Read-Host "Please enter the PRODUCTION hostname of the new application (e.g. crm.incommunities.co.uk)"

#REST Configuration
$BaseUri = "https://dev.azure.com/incommunities/$($ProjectAlias)/_apis/distributedtask"
$AlternateBaseUri = "https://vsrm.dev.azure.com/Incommunities/$($ProjectAlias)/_apis"
$AzureDevOpsAuthenicationHeader = @{Authorization = 'Basic ' + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$($Pat)")) }

#Create project
Write-Host
Write-Host 'Creating project...'

$NewProject = az devops project create --name $ProjectAlias --description $ProjectDescription --source-control git --detect true | ConvertFrom-Json | Null-Check "Project"

#Import template project into solution
Write-Host
Write-Host 'Importing template into repository...'

$ImportedRepo = az repos import create --git-source-url https://incommunities@dev.azure.com/incommunities/Templates/_git/$($Framework) --detect true --project $ProjectAlias --repository $ProjectAlias --requires-authorization | Null-Check "Import"

#Create Global variable group
Write-Host
Write-Host 'Creating Global variable group...'

$GlobalVarGroup = az pipelines variable-group create --name 'Global' --project $ProjectAlias --variables 'DS.IIS_Settings.Path=\\svr-prdfs\DeploymentScript\IIS_Settings.ps1' --detect true | ConvertFrom-Json | Null-Check "Global variable group"

#Create Test variable group
Write-Host
Write-Host 'Creating Test Environment Details variable group...'

$TestVarGroup = az pipelines variable-group create --name 'Test Environment Details' --project $ProjectAlias --variables 'ASPNETCORE_ENVIRONMENT=Test' --detect true | ConvertFrom-Json | Null-Check "Test Environment Details variable group"

#Create Staging variable group
Write-Host
Write-Host 'Creating Staging Environment Details variable group...'

$StageVarGroup = az pipelines variable-group create --name 'Staging Environment Details' --project $ProjectAlias --variables 'ASPNETCORE_ENVIRONMENT=Staging' --detect true | ConvertFrom-Json | Null-Check "Staging Environment Details variable group"

#Create Production variable group
Write-Host
Write-Host 'Creating Production Environment Details variable group...'

$ProductionVarGroup = az pipelines variable-group create --name 'Production Environment Details' --project $ProjectAlias --variables 'ASPNETCORE_ENVIRONMENT=Production' --detect true | ConvertFrom-Json | Null-Check "Production Environment Details variable group"

#Create variables
Write-Host
Write-Host 'Adding additional variables to variable groups...'

Add-Variable $ProjectAlias $TestVarGroup.id 'Hostname' (Get-Environment-Hostname $Hostname "test")
Add-Variable $ProjectAlias $StageVarGroup.id 'Hostname' (Get-Environment-Hostname $Hostname "stage")
Add-Variable $ProjectAlias $ProductionVarGroup.id 'Hostname' $Hostname

Import-Csv -Path "$($PSScriptRoot)\resources\variables.csv" | ForEach-Object {
    if($_.Framework -eq $Framework -or $_.Framework2 -eq $Framework -or $_.Framework -eq "All") {
        $Variable = $_
        $Variable.Secret = [System.Convert]::ToBoolean($Variable.Secret)

        if($Variable.Value -eq "[User-Input]") {
            $Variable.Value = Read-Host "Enter the value for $($Variable.Name)"
        }

        switch ($Variable.Scope) {
            Global { 
                Add-Variable $ProjectAlias $GlobalVarGroup.id $Variable.Name $Variable.Value $Variable.Secret
            }
            Test {
                Add-Variable $ProjectAlias $TestVarGroup.id $Variable.Name $Variable.Value $Variable.Secret
            }
            Stage {
                Add-Variable $ProjectAlias $StageVarGroup.id $Variable.Name $Variable.Value $Variable.Secret
            }
            Production {
                Add-Variable $ProjectAlias $ProductionVarGroup.id $Variable.Name $Variable.Value $Variable.Secret
            }
        }
    }
}

#Configure build pipeline
Write-Host
Write-Host "Creating build pipeline..."

$Pipeline = az pipelines create --yml-path /azure-pipelines.yml --detect true --name $ProjectAlias --project $ProjectAlias --repository $ProjectAlias --branch 'develop' --repository-type tfsgit --skip-first-run | ConvertFrom-Json | Null-Check "Pipeline"

if($Framework -eq "Vue") {
    $GatedPipeline = az pipelines create --yml-path /gated-checkin.yml --detect true --name "Gated Checkin" --project $ProjectAlias --repository $ProjectAlias --branch 'develop' --repository-type tfsgit --skip-first-run | ConvertFrom-Json | Null-Check "Gated Checkin Pipeline"
}

#Create master branch
Write-Host
Write-Host "Creating master branch..."

$Repos = az repos list --project $ProjectAlias --detect true | ConvertFrom-Json

git clone $Repos[0].remoteUrl
Set-Location $ProjectAlias
git checkout -b master
git push --set-upstream origin master

$BranchId = git ls-remote --heads https://incommunities@dev.azure.com/incommunities/$ProjectAlias/_git/$ProjectAlias master | Null-Check "Master branch"

Set-Location ..

#Create develop review policy
Write-Host
Write-Host "Creating develop review policy..."

$DevelopReviewPolicy = Get-Content "$($PSScriptRoot)\policies\develop\required-reviewers.json" | ConvertFrom-Json

$DevelopReviewPolicy.Settings.RequiredReviewerIds[0] = az devops security group list --detect --query "graphGroups[?displayName == '$($ProjectAlias) Team'].originId" --project $ProjectAlias | ConvertFrom-Json
$DevelopReviewPolicy | ConvertTo-Json -Depth 32 | Out-File "$($PSScriptRoot)\policies\develop\temp.json"

$NewDevelopReviewPolicy = az repos policy create --detect --project $ProjectAlias --config "$($PSScriptRoot)\policies\develop\temp.json" | Null-Check "Develop review policy"

Remove-Item "$($PSScriptRoot)\policies\develop\temp.json"

#Create master review policy
Write-Host
Write-Host "Creating master review policy..."

$NewMasterReviewPolicy = az repos policy create --detect --project $ProjectAlias --config "$($PSScriptRoot)\policies\master\required-reviewers.json" | Null-Check "Master review policy"

#Create develop minimum reviewer policy
Write-Host
Write-Host "Creating develop minimum reviewer policy..."

$NewDevelopMinimumReviewerPolicy = az repos policy create --detect --project $ProjectAlias --config "$($PSScriptRoot)\policies\develop\minimum-reviewers.json" | Null-Check "Develop minimum reviewer policy"

#Create master minimum reviewer policy
Write-Host
Write-Host "Creating master minimum reviewer policy..."

$NewMasterMinimumReviewerPolicy = az repos policy create --detect --project $ProjectAlias --config "$($PSScriptRoot)\policies\master\minimum-reviewers.json" | Null-Check "Master minimum reviewer policy"

#Create develop merge strategy policy
Write-Host
Write-Host "Creating develop merge policy..."

$NewDevelopMergePolicy = az repos policy create --detect --project $ProjectAlias --config "$($PSScriptRoot)\policies\develop\merge-strategy.json" | Null-Check "Develop merge strategy policy"

#Create master merge strategy policy
Write-Host
Write-Host "Creating master merge policy..."

$NewMasterMergePolicy = az repos policy create --detect --project $ProjectAlias --config "$($PSScriptRoot)\policies\master\merge-strategy.json" | Null-Check "Master merge strategy policy"

#Create develop work item linking  policy
Write-Host
Write-Host "Creating develop work item linking policy..."

$NewDevelopWorkItemPolicy = az repos policy create --detect --project $ProjectAlias --config "$($PSScriptRoot)\policies\develop\work-item-linking.json" | Null-Check "Develop work item linking policy"

#Create shared comment resolution policy
Write-Host
Write-Host "Creating shared comment resolution policy..."

$NewSharedCommentResolutionPolicy = az repos policy create --detect --project $ProjectAlias --config "$($PSScriptRoot)\policies\shared\comment-resolution.json" | Null-Check "Shared comment resolution policy"

#Create develop build validation policy
Write-Host
Write-Host "Creating shared build validation policy..."

$SharedBuildPolicy = Get-Content "$($PSScriptRoot)\policies\shared\build-validation.json" | ConvertFrom-Json

if($Framework -eq "Vue") {
    $SharedBuildPolicy.Settings.buildDefinitionId = $GatedPipeline.id
} else {
    $SharedBuildPolicy.Settings.buildDefinitionId = $Pipeline.id
}

$SharedBuildPolicy | ConvertTo-Json -Depth 32 | Out-File "$($PSScriptRoot)\policies\shared\temp.json"

$NewSharedBuildPolicy = az repos policy create --detect --project $ProjectAlias --config "$($PSScriptRoot)\policies\shared\temp.json" | Null-Check "Shared build validation policy"

Remove-Item "$($PSScriptRoot)\policies\shared\temp.json"

#Link deployment group via REST api
Write-Host
Write-Host "Linking deployment groups"

if($Framework -eq "MVC" -or $Framework -eq "Vue") {
    $TestDeploymentGroup = Invoke-RestMethod "$($BaseUri)/deploymentgroups?api-version=6.0-preview.1" -ContentType application/json -Body (Get-Content "$($PSScriptRoot)\deployment-groups\test-web.json") -Method Post -Headers $AzureDevOpsAuthenicationHeader | Null-Check "Test Web deployment group"
    $ProdDeploymentGroup = Invoke-RestMethod "$($BaseUri)/deploymentgroups?api-version=6.0-preview.1" -ContentType application/json -Body (Get-Content "$($PSScriptRoot)\deployment-groups\production-web.json") -Method Post -Headers $AzureDevOpsAuthenicationHeader | Null-Check "Production Web deployment group"
} else {
    $TestDeploymentGroup = Invoke-RestMethod "$($BaseUri)/deploymentgroups?api-version=6.0-preview.1" -ContentType application/json -Body (Get-Content "$($PSScriptRoot)\deployment-groups\test-api.json") -Method Post -Headers $AzureDevOpsAuthenicationHeader | Null-Check "Test API deployment group"
    $ProdDeploymentGroup = Invoke-RestMethod "$($BaseUri)/deploymentgroups?api-version=6.0-preview.1" -ContentType application/json -Body (Get-Content "$($PSScriptRoot)\deployment-groups\production-api.json") -Method Post -Headers $AzureDevOpsAuthenicationHeader | Null-Check "Production API deployment group"
}

#Create task group
Write-Host
Write-Host "Creating task groups"

if($Framework -eq "MVC" -or $Framework -eq "API") {
    $TaskGroupResult = Invoke-RestMethod "$($BaseUri)/taskgroups?api-version=6.0-preview.1" -ContentType application/json -Body (Get-Content "$($PSScriptRoot)\task-groups\dotnet-core.json") -Method Post -Headers $AzureDevOpsAuthenicationHeader | Null-Check "Dotnet core task group"
} else {
    $TaskGroupResult = Invoke-RestMethod "$($BaseUri)/taskgroups?api-version=6.0-preview.1" -ContentType application/json -Body (Get-Content "$($PSScriptRoot)\task-groups\vue.json") -Method Post -Headers $AzureDevOpsAuthenicationHeader | Null-Check "Vue task group"
}

#Create release definition
Write-Host
Write-Host "Creating release definition"

$ReleaseDefinition = Get-Content "$($PSScriptRoot)\releases\release.json" | ConvertFrom-Json

$DevelopArtifactAlias = "drop-$($NewProject.name)(develop)"
$MasterArtifactAlias = "drop-$($NewProject.name)(master)"

$ReleaseDefinition.name = $NewProject.name
$ReleaseDefinition.variableGroups[0] = $GlobalVarGroup.id
$ReleaseDefinition.environments[0].variableGroups[0] = $TestVarGroup.id
$ReleaseDefinition.environments[1].variableGroups[0] = $StageVarGroup.id
$ReleaseDefinition.environments[2].variableGroups[0] = $ProductionVarGroup.id

for($i = 0; $i -le 2; $i++) {
    $ReleaseDefinition.environments[$i].deployPhases[0].deploymentInput.artifactsDownloadInput.downloadInputs[0].alias = $DevelopArtifactAlias
    $ReleaseDefinition.environments[$i].deployPhases[0].deploymentInput.artifactsDownloadInput.downloadInputs[1].alias = $MasterArtifactAlias

    $ReleaseDefinition.environments[$i].deployPhases[0].workflowTasks[0].taskId = $TaskGroupResult.Id

    if($i -eq 2){
        $ReleaseDefinition.environments[$i].deployPhases[0].deploymentInput.queueId = $ProdDeploymentGroup.id
    } else {
        $ReleaseDefinition.environments[$i].deployPhases[0].deploymentInput.queueId = $TestDeploymentGroup.id
    }
}


$ReleaseDefinition.artifacts[0].alias = $DevelopArtifactAlias
$ReleaseDefinition.artifacts[1].alias = $MasterArtifactAlias

for($i = 0; $i -le 1; $i++) {
    $ReleaseDefinition.artifacts[$i].definitionReference.project.id = $NewProject.id
    $ReleaseDefinition.artifacts[$i].definitionReference.project.name = $NewProject.name

    $ReleaseDefinition.artifacts[$i].definitionReference.definition.id = $Pipeline.id
    $ReleaseDefinition.artifacts[$i].definitionReference.artifactSourceDefinitionUrl = $Pipeline.url
}

$ReleaseDefinition.triggers[0].artifactAlias = $DevelopArtifactAlias
$ReleaseDefinition.triggers[1].artifactAlias = $MasterArtifactAlias

$ReleaseDefinition | ConvertTo-Json -Depth 32 | Out-File "$($PSScriptRoot)\releases\temp.json"

$CreatedRelease = Invoke-RestMethod "$($AlternateBaseUri)/release/definitions?api-version=6.0" -ContentType application/json -Body (Get-Content "$($PSScriptRoot)\releases\temp.json") -Method Post -Headers $AzureDevOpsAuthenicationHeader | Null-Check "Release definition"

Remove-Item "$($PSScriptRoot)\releases\temp.json"

#Stop logging
Stop-Transcript
