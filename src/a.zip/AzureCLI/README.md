# Introduction
This is a master script to generate a project and associated artifacts
Ensure you have Azure CLI for Windows installed (https://docs.microsoft.com/en-us/cli/azure/install-azure-cli-windows?tabs=azure-cli)


# Getting started
1. Clone this repository and open the `AzureCLI` directory
2. Obtain a PAT (Personal access token) token from Azure DevOps with full permissions (see here for how to create https://docs.microsoft.com/en-us/azure/devops/organizations/accounts/use-personal-access-tokens-to-authenticate?view=azure-devops&tabs=preview-page)
3. Update PAT.txt in `/resources` with the new token
4. Run `Create-Project.ps1`
5. Enter input values when requested (worth noting, not all are prompted at the start of running the script!)

# Notes
The `Create-Project.ps1` script will output a log to the script root directory (`.log` file)

Visual Studio Code is the best place to edit/run this script as Powershell 7 is supported and allows for debugging

`resources/variables.csv` can be updated so that new variables are scripted
