function Add-Variable {
    Param
    (
        [Parameter(Mandatory=$true, Position=0)]
        [string] $ProjectName,

        [Parameter(Mandatory=$true, Position=1)]
        [string] $VariableGroupId,

        [Parameter(Mandatory=$true, Position=2)]
        [string] $VariableName,

        [Parameter(Mandatory=$true, Position=3)]
        [string] $Value,

        [Parameter(Mandatory=$false, Position=4)]
        [bool] $IsSecret = $false

    )

    Write-Host
    Write-Host "Adding $($VariableName) variable..."
    $DeploymentPath = az pipelines variable-group variable create --project $ProjectName --group-id $VariableGroupId --name $VariableName --secret $IsSecret --value $Value | Null-Check $VariableName
}

function Null-Check {
    Param
    (
        [Parameter(ValueFromPipeline)]
        [object] $Data,

        [Parameter(Mandatory=$true, Position=0)]
        [string] $Alias
    )

    if($Data) {
        Write-Host $Alias successfully created! -BackgroundColor DarkGreen
        return $Data
    } else {
        Write-Host $Alias could not be created. -BackgroundColor Red
        exit
    }
}

function Get-Environment-Hostname {
    Param
    (
        [Parameter(Mandatory=$true, Position=0)]
        [string] $Hostname,

        [Parameter(Mandatory=$true, Position=1)]
        [string] $Environment
    )

    $SplitHost = $Hostname.split('.')
    $SplitHost[0] = $SplitHost[0] + '-' + $Environment
    return $SplitHost -Join '.'
}